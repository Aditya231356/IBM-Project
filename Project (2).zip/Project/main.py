import tkinter as tk
import json
import re
import random
from datetime import datetime
import pandas as pd

# Load nutrition data
with open("Zero_Hunger.json", "r") as f:
    nutrition_data = json.load(f)

# Load hunger data (you would load your Excel file here)
# For demonstration, we'll use a sample dictionary
hunger_data = {
    "global": {
        "2020": 8.9,
        "2010": 12.4,
        "2000": 15.2
    },
    "regions": {
        "Sub-Saharan Africa": 20.9,
        "South Asia": 15.9,
        "Latin America": 7.8,
        "East Asia": 4.0
    },
    "countries": {
        "Somalia": 53.1,
        "Central African Republic": 52.2,
        "Haiti": 47.2,
        "India": 16.3,
        "Brazil": 4.1,
        "China": 2.5
    }
}

class AgriHealthChatbotApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AgriHealth Nutrition Chatbot")
        self.root.geometry("600x650")
        self.root.configure(bg="#f0f0f0")
        
        # Conversation history
        self.conversation_history = []
        
        # Common questions patterns
        self.common_questions = {
            r"how are you|how's it going": ["I'm doing well, thanks for asking! How can I help you with your nutrition today?", 
                                           "I'm just a bot, but I'm functioning perfectly! What nutrition questions can I answer for you?"],
            r"what can you do|your capabilities": ["I can provide nutrition advice, meal planning tips, health recommendations, and global hunger statistics. Try asking about specific foods, diets, health conditions, or hunger data!", 
                                                 "I'm your nutrition and hunger expert! Ask me about healthy eating, special diets, vitamins, hunger statistics, or any food-related questions."],
            r"who made you|who created you": ["I was developed by a team of nutritionists and software developers to provide reliable health and hunger information.", 
                                             "My purpose is to make nutrition and hunger information accessible. I was created by combining expert knowledge with AI technology."],
            r"thank you|thanks": ["You're very welcome! Let me know if you have any other nutrition or hunger questions.", 
                                 "Happy to help! Don't hesitate to ask if you need more information about food or hunger."],
            r"goodbye|bye|see you": ["Goodbye! Remember to eat your veggies!", 
                                    "Take care! Come back if you have more nutrition questions.", 
                                    "Bye! Wishing you good health and food security!"],
            r"what time is it|current time": [f"The current time is {datetime.now().strftime('%I:%M %p')}."],
            r"what day is it|today's date": [f"Today is {datetime.now().strftime('%A, %B %d, %Y')}."],
            r"your name|who are you": ["I'm AgriHealth, your nutrition and hunger assistant chatbot!", 
                                      "You can call me AgriHealth - your friendly nutrition and food security guide."],
            r"help|what should I ask": ["Try asking me about: \n- Specific foods (like bananas or salmon)\n- Health conditions (diabetes, pregnancy)\n- Diet types (vegan, keto)\n- Nutrients (protein, vitamin D)\n- Meal ideas or recipes\n- Hunger statistics (global or by country)\n- Food security information"],
            r"joke|funny": ["Why did the tomato turn red? Because it saw the salad dressing!", 
                            "What's a nutritionist's favorite type of math? Pro-tein!",
                            "Why don't food insecure countries play hide and seek? Because good nutrition is hard to hide!"]
        }

        # Hunger-related questions patterns
        self.hunger_questions = {
            r"hunger stats|hunger data|undernourishment": self.get_hunger_stats,
            r"hunger in\s+([a-zA-Z\s]+)": self.get_country_hunger_stats,
            r"global hunger|world hunger": lambda: self.get_hunger_stats("global"),
            r"most hungry|worst hunger": lambda: self.get_hunger_stats("worst"),
            r"improved hunger|best improvement": lambda: self.get_hunger_stats("improved"),
            r"food security|food insecurity": self.get_food_security_info,
            r"zero hunger|sdg 2": self.get_zero_hunger_info
        }

        self.create_widgets()
        self.bind_events()
        
        # Initial greeting
        self.display_message("Bot", self.get_greeting())

    def create_widgets(self):
        # Chat display
        self.chat_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.chat_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        self.chat_log = tk.Text(self.chat_frame, bd=1, bg="white", wrap="word", 
                               font=("Arial", 12), padx=10, pady=10)
        self.chat_log.pack(fill=tk.BOTH, expand=True)
        self.chat_log.config(state=tk.DISABLED)
        
        # Scrollbar
        scrollbar = tk.Scrollbar(self.chat_log)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.chat_log.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.chat_log.yview)
        
        # Input area
        self.input_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.input_frame.pack(padx=10, pady=10, fill=tk.X)
        
        self.entry = tk.Entry(self.input_frame, font=("Arial", 12), 
                             bd=2, relief=tk.GROOVE)
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        self.send_button = tk.Button(self.input_frame, text="Send", 
                                   command=self.send_message,
                                   bg="#4CAF50", fg="white", 
                                   font=("Arial", 12, "bold"))
        self.send_button.pack(side=tk.RIGHT)
        
        # Add some styling
        self.root.option_add('*Font', 'Arial 12')
        self.chat_log.tag_config('user', foreground='blue')
        self.chat_log.tag_config('bot', foreground='green')
        self.chat_log.tag_config('stats', foreground='purple')

    def bind_events(self):
        self.entry.bind("<Return>", lambda event: self.send_message())
        self.root.bind("<Control-q>", lambda event: self.root.destroy())

    def send_message(self):
        user_input = self.entry.get().strip()
        if not user_input:
            return

        self.display_message("You", user_input)
        self.conversation_history.append(("user", user_input))
        
        # Process after a slight delay for more natural feel
        self.root.after(150, lambda: self.process_user_input(user_input))
        self.entry.delete(0, tk.END)

    def process_user_input(self, user_input):
        response = self.get_bot_response(user_input.lower())
        self.display_message("Bot", response)
        self.conversation_history.append(("bot", response))

    def display_message(self, sender, message):
        self.chat_log.config(state=tk.NORMAL)
        tag = 'user' if sender == "You" else 'bot'
        
        # Use special tag for statistics
        if any(term in message.lower() for term in ["%", "statistic", "data", "hunger rate"]):
            tag = 'stats'
            
        self.chat_log.insert(tk.END, f"{sender}: ", tag)
        self.chat_log.insert(tk.END, f"{message}\n\n", tag)
        self.chat_log.config(state=tk.DISABLED)
        self.chat_log.see(tk.END)

    def get_greeting(self):
        hour = datetime.now().hour
        if 5 <= hour < 12:
            return random.choice([
                "Good morning! I'm AgriHealth, your nutrition and hunger assistant. How can I help you today?",
                "Morning sunshine! Ready to talk about healthy eating and food security?"
            ])
        elif 12 <= hour < 17:
            return random.choice([
                "Good afternoon! What nutrition or hunger questions can I answer for you?",
                "Afternoon! How can I assist with your health or food security goals today?"
            ])
        elif 17 <= hour < 22:
            return random.choice([
                "Good evening! I'm here to help with your nutrition and hunger queries.",
                "Evening! What would you like to know about healthy eating or global hunger?"
            ])
        else:
            return random.choice([
                "Hello night owl! I'm here for your late-night nutrition and hunger questions.",
                "Up late? I can help with any nutrition or food security info you need."
            ])

    def get_bot_response(self, user_input):
        # Check for common questions first
        for pattern, responses in self.common_questions.items():
            if re.search(pattern, user_input):
                return random.choice(responses)
        
        # Check for hunger-related questions
        for pattern, handler in self.hunger_questions.items():
            match = re.search(pattern, user_input)
            if match:
                if match.groups():
                    return handler(match.group(1).strip())
                return handler().strip()
        
        # Check for greetings
        greeting_responses = {
            "hello": ["Hello! How can I help you with nutrition or hunger today?", 
                     "Hi there! Ask me anything about food, health, or hunger statistics."],
            "hi": ["Hi! What would you like to know about nutrition or food security?", 
                   "Hello! I'm here to help with your health and hunger questions."],
            "hey": ["Hey there! What's your nutrition or hunger question today?", 
                    "Hey! Ready to talk about healthy eating or food security?"],
            "namaste": ["Namaste! Swasthya aur khaadya suraksha sambandhi kisi bhi sawal ke liye poocho!", 
                        "Namaste! Aapke nutrition aur bhookh ke sawaal ka intezaar hai."]
        }
        
        for greeting in greeting_responses:
            if greeting in user_input:
                return random.choice(greeting_responses[greeting])
        
        # Check for nutrition queries
        matched_responses = []
        for key, value in nutrition_data.items():
            # Split multi-word keys and check for any match
            keywords = key.split('_')
            for keyword in keywords:
                if re.search(rf"\b{keyword}\b", user_input):
                    matched_responses.append(value)
                    break  # No need to check other keywords for this entry
        
        if matched_responses:
            # If multiple matches, return the most specific one (longest response)
            return max(matched_responses, key=len)
        
        # Fallback responses
        fallbacks = [
            "I'm not sure I understand. Could you rephrase your question about nutrition or hunger?",
            "I specialize in nutrition and hunger advice. Could you ask about food, diets, health, or food security?",
            "Hmm, I don't have an answer for that. Try asking about nutrition, healthy eating, or hunger statistics!",
            "I'm designed to answer nutrition and hunger questions. Maybe ask about vitamins, diets, meal planning, or food insecurity?",
            "That's an interesting question! I'm best at answering nutrition and hunger-related queries though."
        ]
        
        # If we have conversation history, try to continue context
        if self.conversation_history:
            last_user_q = self.conversation_history[-2][1].lower() if len(self.conversation_history) >= 2 else ""
            
            # Handle follow-up questions
            if any(word in user_input for word in ["more", "else", "another", "other"]):
                return random.choice([
                    "Would you like more detailed information about this topic?",
                    "I can provide additional resources if you'd like.",
                    "Is there another aspect of this you're curious about?"
                ])
            
            # Handle unclear responses
            if any(word in user_input for word in ["what", "mean", "explain"]):
                return random.choice([
                    "Let me clarify that for you...",
                    "To explain differently...",
                    "In simpler terms..."
                ] + matched_responses)  # Try matching again with simpler terms
        
        return random.choice(fallbacks)

    # Hunger-related response functions
    def get_hunger_stats(self, scope="general"):
        if scope == "global":
            return (
                "Global hunger statistics:\n"
                f"- 2020: {hunger_data['global']['2020']}% of world population undernourished\n"
                f"- 2010: {hunger_data['global']['2010']}%\n"
                f"- 2000: {hunger_data['global']['2000']}%\n"
                "While progress has been made, COVID-19 reversed some gains."
            )
        elif scope == "worst":
            return (
                "Countries with highest undernourishment rates:\n"
                f"- Somalia: {hunger_data['countries']['Somalia']}%\n"
                f"- Central African Republic: {hunger_data['countries']['Central African Republic']}%\n"
                f"- Haiti: {hunger_data['countries']['Haiti']}%\n"
                "These countries face conflict, climate challenges, and economic instability."
            )
        elif scope == "improved":
            return (
                "Countries that improved hunger significantly:\n"
                f"- China: Reduced from 10% to {hunger_data['countries']['China']}%\n"
                f"- Brazil: Reduced from 10.7% to {hunger_data['countries']['Brazil']}%\n"
                f"- Cambodia: Reduced from 23.6% to 6.3%\n"
                "These successes came from economic growth, agriculture investments, and social programs."
            )
        else:
            return (
                "Key global hunger facts:\n"
                f"- Sub-Saharan Africa: {hunger_data['regions']['Sub-Saharan Africa']}% undernourished\n"
                f"- South Asia: {hunger_data['regions']['South Asia']}%\n"
                f"- Global average: {hunger_data['global']['2020']}%\n"
                "Ask about a specific country or region for more details."
            )

    def get_country_hunger_stats(self, country):
        country = country.strip().title()
        if country in hunger_data['countries']:
            rate = hunger_data['countries'][country]
            tips = self.get_country_nutrition_tips(country, rate)
            return (
                f"Hunger statistics for {country}:\n"
                f"- Undernourishment rate: {rate}% of population\n\n"
                f"Nutrition tips for {country}:\n{tips}"
            )
        else:
            similar = [c for c in hunger_data['countries'] if country.lower() in c.lower()]
            if similar:
                return f"I don't have data for {country}, but I have info for: {', '.join(similar)}"
            return f"I don't have specific hunger data for {country}. Try asking about a region or major country."

    def get_country_nutrition_tips(self, country, rate):
        if rate > 30:
            return (
                "With high undernourishment, focus on:\n"
                "- Fortified staple foods\n"
                "- High-energy density foods\n"
                "- Community nutrition programs\n"
                "- Addressing food distribution challenges"
            )
        elif rate > 15:
            return (
                "Nutrition priorities:\n"
                "- Diverse diets with available local foods\n"
                "- Micronutrient supplementation\n"
                "- School feeding programs\n"
                "- Small-scale agriculture support"
            )
        else:
            return (
                "Nutrition focus areas:\n"
                "- Balanced diets\n"
                "- Reducing processed foods\n"
                "- Sustainable food systems\n"
                "- Nutrition education"
            )

    def get_food_security_info(self):
        return (
            "Food security means all people have access to sufficient, safe, nutritious food.\n\n"
            "Four dimensions:\n"
            "1. Availability (production and supply)\n"
            "2. Access (economic and physical)\n"
            "3. Utilization (nutrition and preparation)\n"
            "4. Stability (over time)\n\n"
            "Ask about food security in specific countries for more details."
        )

    def get_zero_hunger_info(self):
        return (
            "Zero Hunger is UN Sustainable Development Goal 2 (SDG 2).\n\n"
            "Targets include:\n"
            "- Ending hunger by 2030\n"
            "- Ending all forms of malnutrition\n"
            "- Doubling agricultural productivity\n"
            "- Sustainable food production systems\n\n"
            "Current progress shows challenges but also success stories in some countries."
        )


if __name__ == "__main__":
    root = tk.Tk()
    app = AgriHealthChatbotApp(root)
    root.mainloop()